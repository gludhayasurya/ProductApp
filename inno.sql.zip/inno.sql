-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 09, 2024 at 03:52 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inno`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `log_name` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `subject_type` varchar(255) DEFAULT NULL,
  `event` varchar(255) DEFAULT NULL,
  `subject_id` bigint(20) UNSIGNED DEFAULT NULL,
  `causer_type` varchar(255) DEFAULT NULL,
  `causer_id` bigint(20) UNSIGNED DEFAULT NULL,
  `properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`properties`)),
  `batch_uuid` char(36) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`id`, `log_name`, `description`, `subject_type`, `event`, `subject_id`, `causer_type`, `causer_id`, `properties`, `batch_uuid`, `created_at`, `updated_at`) VALUES
(1, 'default', 'User logged in', 'App\\Models\\User', NULL, 1, 'App\\Models\\User', 1, '[]', NULL, '2024-07-09 07:42:23', '2024-07-09 07:42:23'),
(2, 'default', 'updated', 'App\\Models\\Product', 'updated', 18, 'App\\Models\\User', 1, '{\"attributes\":{\"id\":18,\"name\":\"Pro Log\",\"price\":\"567.00\",\"sku\":\"ghghghgh\",\"description\":\"Checking the logactivity Edit\",\"images\":\"[\\\"images\\\\\\/Hca5t6NzfXxQcH0dYo0Ynjr3T8y2ZBL9OsSYRC7d.jpg\\\"]\",\"created_at\":\"2024-07-09T13:12:58.000000Z\",\"updated_at\":\"2024-07-09T13:13:50.000000Z\"},\"old\":{\"id\":18,\"name\":\"Pro Log\",\"price\":\"567.00\",\"sku\":\"ghghghgh\",\"description\":\"Checking the logactivity\",\"images\":\"[\\\"images\\\\\\/Hca5t6NzfXxQcH0dYo0Ynjr3T8y2ZBL9OsSYRC7d.jpg\\\"]\",\"created_at\":\"2024-07-09T13:12:58.000000Z\",\"updated_at\":\"2024-07-09T13:12:58.000000Z\"}}', NULL, '2024-07-09 07:43:50', '2024-07-09 07:43:50'),
(3, 'default', 'created', 'App\\Models\\Product', 'created', 19, 'App\\Models\\User', 1, '{\"attributes\":{\"id\":19,\"name\":\"Pro 888\",\"price\":\"1245.00\",\"sku\":\"tttttt\",\"description\":\"bbbbbbbbbbbbbbbbb\",\"images\":\"[]\",\"created_at\":\"2024-07-09T13:14:33.000000Z\",\"updated_at\":\"2024-07-09T13:14:33.000000Z\"}}', NULL, '2024-07-09 07:44:33', '2024-07-09 07:44:33'),
(4, 'default', 'created', 'App\\Models\\Product', 'created', 20, 'App\\Models\\User', 1, '{\"attributes\":{\"id\":20,\"name\":\"Pro Attch\",\"price\":\"666.00\",\"sku\":\"rerererer\",\"description\":\"attcah check\",\"images\":\"[\\\"images\\\\\\/XN6hsAlVC1uaVUxnNWjwO6qmg8BLJ8irYW2a7nAe.jpg\\\"]\",\"created_at\":\"2024-07-09T13:19:37.000000Z\",\"updated_at\":\"2024-07-09T13:19:37.000000Z\"}}', NULL, '2024-07-09 07:49:39', '2024-07-09 07:49:39'),
(5, 'default', 'created', 'App\\Models\\Product', 'created', 21, 'App\\Models\\User', 1, '{\"attributes\":{\"id\":21,\"name\":\"Pro Attch\",\"price\":\"666.00\",\"sku\":\"rerererer\",\"description\":\"attcah check\",\"images\":\"[\\\"images\\\\\\/44DYlxfEntoTtma8FGz3tCzegRsODICCeCtNz8fw.jpg\\\"]\",\"created_at\":\"2024-07-09T13:20:15.000000Z\",\"updated_at\":\"2024-07-09T13:20:15.000000Z\"}}', NULL, '2024-07-09 07:50:16', '2024-07-09 07:50:16'),
(6, 'default', 'created', 'App\\Models\\Product', 'created', 22, 'App\\Models\\User', 1, '{\"attributes\":{\"id\":22,\"name\":\"Pro Attch\",\"price\":\"666.00\",\"sku\":\"rerererer\",\"description\":\"attcah check\",\"images\":[\"images\\/14Ws8xoYbFsTxPJeiTS3AvRXDHtO5cDg5dmLStOe.jpg\"],\"created_at\":\"2024-07-09T13:23:27.000000Z\",\"updated_at\":\"2024-07-09T13:23:27.000000Z\"}}', NULL, '2024-07-09 07:53:28', '2024-07-09 07:53:28'),
(7, 'default', 'created', 'App\\Models\\Product', 'created', 23, 'App\\Models\\User', 1, '{\"attributes\":{\"id\":23,\"name\":\"Pro Attch\",\"price\":\"666.00\",\"sku\":\"rerererer\",\"description\":\"attcah check\",\"images\":[\"images\\/EzUPrWPcbPbi8UqSuWZCcTcNWl1RJtEn2uAHOY3v.jpg\"],\"created_at\":\"2024-07-09T13:23:40.000000Z\",\"updated_at\":\"2024-07-09T13:23:40.000000Z\"}}', NULL, '2024-07-09 07:53:40', '2024-07-09 07:53:40'),
(8, 'default', 'created', 'App\\Models\\Product', 'created', 24, 'App\\Models\\User', 1, '{\"attributes\":{\"id\":24,\"name\":\"Pro Attch\",\"price\":\"666.00\",\"sku\":\"rerererer\",\"description\":\"attcah check\",\"images\":[\"images\\/dNX9EzofTdPlIdj01APZYMrR3MNaeJzT5D5DlKOK.jpg\"],\"created_at\":\"2024-07-09T13:25:50.000000Z\",\"updated_at\":\"2024-07-09T13:25:50.000000Z\"}}', NULL, '2024-07-09 07:55:50', '2024-07-09 07:55:50'),
(9, 'default', 'created', 'App\\Models\\Product', 'created', 25, 'App\\Models\\User', 1, '{\"attributes\":{\"id\":25,\"name\":\"Pro Attch\",\"price\":\"666.00\",\"sku\":\"rerererer\",\"description\":\"attcah check\",\"images\":\"[\\\"images\\\\\\/ZXrdD3sWpf0kqW0OQa6lZQbLfTNhDheCy3suN2Sv.jpg\\\"]\",\"created_at\":\"2024-07-09T13:38:31.000000Z\",\"updated_at\":\"2024-07-09T13:38:31.000000Z\"}}', NULL, '2024-07-09 08:08:31', '2024-07-09 08:08:31'),
(10, 'default', 'created', 'App\\Models\\Product', 'created', 26, 'App\\Models\\User', 1, '{\"attributes\":{\"id\":26,\"name\":\"Pro Attch\",\"price\":\"666.00\",\"sku\":\"rerererer\",\"description\":\"attcah check\",\"images\":\"[\\\"images\\\\\\/oOSe8oAqPqFPmLVBla7jqRE3HWoTp3w0yHihYKgs.jpg\\\"]\",\"created_at\":\"2024-07-09T13:40:18.000000Z\",\"updated_at\":\"2024-07-09T13:40:18.000000Z\"}}', NULL, '2024-07-09 08:10:19', '2024-07-09 08:10:19'),
(11, 'default', 'User logged out', 'App\\Models\\User', NULL, 1, 'App\\Models\\User', 1, '[]', NULL, '2024-07-09 08:11:16', '2024-07-09 08:11:16');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2024_07_08_120043_create_products_table', 1),
(6, '2024_07_09_125514_create_activity_log_table', 2),
(7, '2024_07_09_125515_add_event_column_to_activity_log_table', 2),
(8, '2024_07_09_125516_add_batch_uuid_column_to_activity_log_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `otps`
--

CREATE TABLE `otps` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `otp` varchar(6) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `sku` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`images`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `sku`, `description`, `images`, `created_at`, `updated_at`) VALUES
(1, 'Product 1 Updateddd', 150.00, '1234567890', 'Good Product', '[\"images\\/MTnfH0S6oxXRxf4e4s4SF95EjQx2pQPzkDxcfj32.jpg\"]', '2024-07-09 04:12:51', '2024-07-09 04:40:23'),
(3, 'Product 3', 250.00, '123123', 'Image checking', '[\"images\\/gt52OISXO3HT4zLx43QxH9plfgIbHfs7wSZUigYd.jpg\"]', '2024-07-09 05:33:39', '2024-07-09 05:33:39'),
(4, 'Product 3', 250.00, '123123', 'Image checking', '[\"images\\/FDX5Z0Zs5ZVYRBn8yWOf5j6RlrtrPMXDwXoJabDf.jpg\"]', '2024-07-09 05:35:07', '2024-07-09 05:35:07'),
(5, 'Product 3', 250.00, '123123', 'Image checking', '[\"images\\/UBmPSOEQSOwqOBBwMDTtx1AkNV1LMCfv0k11oeA8.jpg\"]', '2024-07-09 05:38:32', '2024-07-09 05:38:32'),
(6, 'Product 3', 250.00, '123123', 'Image checking', '[\"images\\/EtK7wgkJEzcdGP5GPqjlsg0Gai4kZ5ECVXIZ2Ksi.jpg\"]', '2024-07-09 05:45:48', '2024-07-09 05:45:48'),
(7, 'Product 4', 678.00, 'utyr8s343', 'Nice', '[\"images\\/KA33WXkofaeOrweneNUYvXY4tOTFBGihev9VJbxS.jpg\"]', '2024-07-09 06:10:37', '2024-07-09 06:10:37'),
(8, 'Product 4', 678.00, 'utyr8s343', 'Nice', '[\"images\\/61Ia6PJvZ6sJ4lc9ny8X1DKTgwzggVXcDAvtLYvI.jpg\"]', '2024-07-09 06:12:17', '2024-07-09 06:12:17'),
(9, 'Product 4', 678.00, 'utyr8s343', 'Nice', '[\"images\\/4ZMZFlgXkVWzP9LSyAsaDRses3cInTu85dEmvppx.jpg\"]', '2024-07-09 06:12:57', '2024-07-09 06:12:57'),
(10, 'Product 4', 678.00, 'utyr8s343', 'Nice', '[\"images\\/5TWbRZyZYQDY5vL1oG0baFl1mrOlqI6tnC9ovTgo.jpg\"]', '2024-07-09 06:15:04', '2024-07-09 06:15:04'),
(11, 'Product 4', 678.00, 'utyr8s343', 'Nice', '[\"images\\/ZiCGoPPIsYuBppiVnYkxG3ZejZpAyIuFceXZAd6N.jpg\"]', '2024-07-09 06:25:50', '2024-07-09 06:25:50'),
(12, 'Product 4', 678.00, 'utyr8s343', 'Nice', '[\"images\\/4aRPEmcwO1c5DtrtRPQvuMhRtnLCdQz1FTsaDS5m.jpg\"]', '2024-07-09 06:26:17', '2024-07-09 06:26:17'),
(13, 'Product 4', 678.00, 'utyr8s343', 'Nice', '[\"images\\/4VaXVtzWZ06sBwP6JnGeJFHaCMzJP3E2epclFSJ5.jpg\"]', '2024-07-09 06:29:10', '2024-07-09 06:29:10'),
(14, 'Product 4', 678.00, 'utyr8s343', 'Nice', '[\"images\\/52yBZqmWnXuk84VLW6heHs809m3I6lo33M6PbaCY.jpg\"]', '2024-07-09 06:30:55', '2024-07-09 06:30:55'),
(15, 'Product 4', 678.00, 'utyr8s343', 'Nice', '[\"images\\/w4wBTDpe0iqMTZBn0eY8oCXJyuZa9gPZev92TsA9.jpg\"]', '2024-07-09 06:31:05', '2024-07-09 06:31:05'),
(16, 'Product 4', 678.00, 'utyr8s343', 'Nice', '[\"images\\/rVvflmlzVezbkOlQ0RS9ncjOeUnqk0i9Bmmc6FU7.jpg\"]', '2024-07-09 06:34:50', '2024-07-09 06:34:50'),
(17, 'Product 5', 12345.00, 'swswsw', 'Amazed', '[\"images\\/xOgnT2Vu30EvXhaRuhrRT3Mwuw3h3B0AILTxCl9g.jpg\"]', '2024-07-09 06:36:30', '2024-07-09 06:36:30'),
(18, 'Pro Log', 567.00, 'ghghghgh', 'Checking the logactivity Edit', '[\"images\\/Hca5t6NzfXxQcH0dYo0Ynjr3T8y2ZBL9OsSYRC7d.jpg\"]', '2024-07-09 07:42:58', '2024-07-09 07:43:50'),
(19, 'Pro 888', 1245.00, 'tttttt', 'bbbbbbbbbbbbbbbbb', '[]', '2024-07-09 07:44:33', '2024-07-09 07:44:33'),
(20, 'Pro Attch', 666.00, 'rerererer', 'attcah check', '[\"images\\/XN6hsAlVC1uaVUxnNWjwO6qmg8BLJ8irYW2a7nAe.jpg\"]', '2024-07-09 07:49:37', '2024-07-09 07:49:37'),
(21, 'Pro Attch', 666.00, 'rerererer', 'attcah check', '[\"images\\/44DYlxfEntoTtma8FGz3tCzegRsODICCeCtNz8fw.jpg\"]', '2024-07-09 07:50:15', '2024-07-09 07:50:15'),
(22, 'Pro Attch', 666.00, 'rerererer', 'attcah check', '[\"images\\/14Ws8xoYbFsTxPJeiTS3AvRXDHtO5cDg5dmLStOe.jpg\"]', '2024-07-09 07:53:27', '2024-07-09 07:53:27'),
(23, 'Pro Attch', 666.00, 'rerererer', 'attcah check', '[\"images\\/EzUPrWPcbPbi8UqSuWZCcTcNWl1RJtEn2uAHOY3v.jpg\"]', '2024-07-09 07:53:40', '2024-07-09 07:53:40'),
(24, 'Pro Attch', 666.00, 'rerererer', 'attcah check', '[\"images\\/dNX9EzofTdPlIdj01APZYMrR3MNaeJzT5D5DlKOK.jpg\"]', '2024-07-09 07:55:50', '2024-07-09 07:55:50'),
(25, 'Pro Attch', 666.00, 'rerererer', 'attcah check', '[\"images\\/ZXrdD3sWpf0kqW0OQa6lZQbLfTNhDheCy3suN2Sv.jpg\"]', '2024-07-09 08:08:31', '2024-07-09 08:08:31'),
(26, 'Pro Attch', 666.00, 'rerererer', 'attcah check', '[\"images\\/oOSe8oAqPqFPmLVBla7jqRE3HWoTp3w0yHihYKgs.jpg\"]', '2024-07-09 08:10:18', '2024-07-09 08:10:18');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'Udhaya', 'abcd@gmail.com', '$2y$12$rBE1zO5TB1.ZUHqB30PPVeMfbCN0mk.D.hfkixwMxrFkbVQ4t6Pfa', '2024-07-09 02:45:24', '2024-07-09 02:45:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subject` (`subject_type`,`subject_id`),
  ADD KEY `causer` (`causer_type`,`causer_id`),
  ADD KEY `activity_log_log_name_index` (`log_name`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `otps`
--
ALTER TABLE `otps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `otps`
--
ALTER TABLE `otps`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
